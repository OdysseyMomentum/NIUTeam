import re
import requests
import json
import numpy as np
import pandas as pd
import pdfplumber #text extraction from pdf
import tabula #table extraction from pdf
import datefinder
import pprint # todo remove me
import en_core_web_sm #NLP model


from langid.langid import LanguageIdentifier, model #language identification
identifier = LanguageIdentifier.from_modelstring(model, norm_probs=True) #static lang. identifier

#regex definitions, here they apply to full doc.
#TODO: Use start and end-of-string ^ $ by tokenizing appropriately and mapping to each token

dateRegex = '([0]?[1-9]|[1|2][0-9]|[3][0|1])[./-]([0]?[1-9]|[1][0-2])[./-]([0-9]{4}|[0-9]{2})'
dateRegexAmerican = r'(?<![/\d])(?:0\d|[1][012])/(?:19|20)?\d{2}(?![/\d])'
ibanRegex = '([A-Z]{2}[ \-]?[0-9]{2})(?=(?:[ \-]?[A-Z0-9]){9,30})((?:[ \-]?[A-Z0-9]{3,5}){2,7})([ \-]?[A-Z0-9]{1,3})?'
emailRegex = "([a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+)"
phoneNumberRegex = "(\+\d{1,2}\s?)?1?\-?\.?\s?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}"
currencyRegex = u"[$¢£¤¥֏؋৲৳৻૱௹฿៛\u20a0-\u20bd\ua838\ufdfc\ufe69\uff04\uffe0\uffe1\uffe5\uffe6]"


nlpCoreWeb = en_core_web_sm.load()

def complete_text(source, entity):
    t=entity.text
    try:
        float( t[0] + t[len(t)-1] )
    except:
        return t
    if entity[0].nbor(-1).is_currency:
        return entity[0].nbor(-1).text + t
    else:
        return t + entity[0].nbor(1).text

def extractfromdoc(event, context):

    resultDict = {}
    url = event[2]['resource']
    r = requests.get(url)
    resultDict['url'] = url

    #TODO: check file i/o, read from s3 directly without download
    with open('/tmp/test.pdf', 'wb') as f:
       f.write(r.content)

    with pdfplumber.open('/tmp/test.pdf') as pdf:
       first_page = pdf.pages[0]
       text = first_page.extract_text()

    resultDict['text'] = text

    #text = text + "\r\n dummy bank info: SE35 5000 0000 0549 1000 0003 "
    #text = text + "\r\n dummy bank info: LU12 3456 7890 0000 0000 0001 "
    #text = text + "\r\n dummy bank phone contact: +352 123456789-10"
    #text = text + "\r\n Peter Parker and Sam Fisher"

    dates = []
    dateMatches = re.finditer(dateRegex, text)
    for match in dateMatches:
        dates.append(match.group(0))

    dateMatchesAmerican = re.finditer(dateRegexAmerican, text)
    for match in dateMatchesAmerican:
        dates.append(match.group(0))

    ibanMatches = re.finditer(ibanRegex, text)
    ibans = []
    for iban in ibanMatches:
         ibans.append(iban.group(0))

    resultDict['iban'] = ibans

    text = re.sub(ibanRegex,'',text) #clear ibans from text, NER doesnt like them

    emails = []
    addressMatches = re.finditer(emailRegex, text)
    for email in addressMatches:
         emails.append(email.group(0))

    resultDict['e-mail'] = emails

    phoneNumbers = []
    phoneMatches = re.finditer(phoneNumberRegex, text)
    for number in phoneMatches:
         phoneNumbers.append(number.group(0))

    resultDict['phone_numbers'] = phoneNumbers

    df = tabula.read_pdf('/tmp/test.pdf', pages = '1')

    languageConfidenceTuple = identifier.classify(text);



#   NER
    docCore = nlpCoreWeb(text)

    tokenList  = [i.text for i in docCore]


    orgs = []
    locs = []
    prods = []
    people = []
    amounts = []

    people.append([ent.text for ent in docCore.ents if ent.label_ == "PERSON" and ent.text.replace(' ','').isalpha()])
    orgs.append([ent.text for ent in docCore.ents if ent.label_ == "ORG" or ent.label_ == "NORP"])
    locs.append([ent.text for ent in docCore.ents if ent.label_ == "LOC" or ent.label_=="GPE"])
    amounts.append([complete_text(docCore, ent) for ent in docCore.ents if ent.label_ == "MONEY"])

    dates.append([ent.text for ent in docCore.ents if ent.label_ == "DATE"])

    resultDict['tables'] = [df[i].to_dict() for i in range(len(df))]


    #resultDict['tokens'] = tokenList

    totals = []
    #line-based results
    for item in text.split("\n"):
       if("total" in item.lower()):
          totals.append(item)
       if(re.match(currencyRegex,item)):
          resultDict['amounts'].append(item)

    resultDict['total'] = totals

    pp = pprint.PrettyPrinter(indent=4)


    #NER results
    resultDict['people'] = people
    resultDict['dates'] = dates
    resultDict['orgs'] = orgs
    resultDict['prods'] = prods
    resultDict['amounts'] = amounts


    resultDict['language_code'] = languageConfidenceTuple[0]
    resultDict['language_conf'] = languageConfidenceTuple[1]

    #response = {
    #    "statusCode": 200,
    #    "body": json.dumps(resultDict)
    #}

    resultDict['statusCode'] = 200
#    pp.pprint(resultDict)

    return resultDict #response
